# 킹 레거시 모바일 피쉬 매크로 (Android 프로젝트)

## APK 만들기
### A) Android Studio (PC)
1. 이 폴더를 Android Studio로 열기 → Gradle Sync
2. Build ▸ Build APK(s) → `app/build/outputs/apk/debug/app-debug.apk`

### B) GitHub Actions (PC/폰 브라우저 모두 가능, 설치 불필요)
1. GitHub에 새 저장소를 만들고 이 폴더 내용 전체를 업로드 (`.github` 폴더 포함)
2. Actions 탭 → "Build APK" → Run workflow
3. 끝나면 Artifacts의 `KingLegacyFishMacro-apk` 다운로드 → 압축 풀면 `app-debug.apk`

## 사용법
1. 앱 실행 → **1. 오버레이 권한** 허용
2. **2. 접근성 설정 열기** → 설치된 앱 → '킹 레거시 모바일 피쉬 매크로' 켜기
   (회색이라 안 켜지면 앱 정보 ▸ ⋮ ▸ 제한된 설정 허용)
3. Roblox(킹 레거시)를 먼저 실행해 두고 **3. 화면 캡처 시작** → "앱 하나 공유" → Roblox 선택 → 다음
4. 게임에서 낚시 미니게임이 떠 있을 때 오버레이의 **[영역 지정]** → ① 흰 막대 탭 ② 포인터 탭
5. **[누를 위치]** → 막대 쪽 빈 곳 한 번 탭 (캐스팅/릴링 때 이 자리를 길게 누릅니다)
6. **[시작]**
