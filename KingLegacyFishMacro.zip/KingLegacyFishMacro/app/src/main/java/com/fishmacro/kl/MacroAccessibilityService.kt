package com.fishmacro.kl

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

/**
 * 같은 자리를 계속 누르고 있는(홀드) 제스처를 만들어 주는 접근성 서비스.
 * 짧은 구간(80ms)을 이어 붙이는 방식(continueStroke)이라, setHold(false)를 부르면 곧바로 손을 뗍니다.
 */
class MacroAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: MacroAccessibilityService? = null
    }

    private val main = Handler(Looper.getMainLooper())
    private var wantHold = false
    private var inFlight = false
    private var lastStroke: GestureDescription.StrokeDescription? = null
    private var hx = 0f
    private var hy = 0f

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    /** want=true: (x,y)를 누른 채 유지, want=false: 손 떼기. 어느 스레드에서 불러도 됩니다. */
    fun setHold(want: Boolean, x: Float, y: Float) {
        main.post {
            if (want && lastStroke == null && !inFlight) {
                hx = x
                hy = y
            }
            wantHold = want
            pump()
        }
    }

    private fun pump() {
        if (inFlight) return
        if (wantHold || lastStroke != null) dispatchSeg()
    }

    private fun dispatchSeg() {
        val path = Path().apply { moveTo(hx, hy) }
        val cont = wantHold
        val prev = lastStroke
        val dur = if (cont) 80L else 10L
        val stroke = if (prev == null) {
            GestureDescription.StrokeDescription(path, 0L, dur, cont)
        } else {
            prev.continueStroke(path, 0L, dur, cont)
        }
        val g = GestureDescription.Builder().addStroke(stroke).build()
        inFlight = true
        val ok = dispatchGesture(g, object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                inFlight = false
                lastStroke = if (cont) stroke else null
                pump()
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                inFlight = false
                lastStroke = null
                pump()
            }
        }, main)
        if (!ok) {
            inFlight = false
            lastStroke = null
        }
    }
}
