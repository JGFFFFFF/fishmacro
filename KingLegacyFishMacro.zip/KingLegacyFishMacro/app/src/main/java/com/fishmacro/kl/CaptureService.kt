package com.fishmacro.kl

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.provider.MediaStore
import android.util.DisplayMetrics
import android.view.WindowManager

/** MediaProjection(화면 공유)으로 게임 화면을 계속 받아두고, 오버레이 패널/매크로 루프를 소유하는 포그라운드 서비스 */
class CaptureService : Service() {

    companion object {
        @Volatile
        var instance: CaptureService? = null
        const val CH = "klfish"
    }

    private var projection: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private lateinit var thread: HandlerThread
    private lateinit var handler: Handler
    private var overlay: OverlayPanel? = null
    private val bot = FishBot()

    private val lock = Any()
    private var bmp: Bitmap? = null
    @Volatile private var fw = 0
    @Volatile private var fh = 0
    private var realW = 0
    private var realH = 0
    private var dpi = 320

    private val cb = object : MediaProjection.Callback() {
        override fun onStop() {
            handler.post { stopSelf() }
        }
    }

    private val listener = ImageReader.OnImageAvailableListener { r ->
        val img = r.acquireLatestImage() ?: return@OnImageAvailableListener
        try {
            val p = img.planes[0]
            val stride = p.rowStride / p.pixelStride
            synchronized(lock) {
                var b = bmp
                if (b == null || b.width != stride || b.height != img.height) {
                    b?.recycle()
                    b = Bitmap.createBitmap(stride, img.height, Bitmap.Config.ARGB_8888)
                    bmp = b
                }
                b!!.copyPixelsFromBuffer(p.buffer)
                fw = img.width
                fh = img.height
            }
        } finally {
            img.close()
        }
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        Prefs.init(this)
        thread = HandlerThread("klfish-cap").also { it.start() }
        handler = Handler(thread.looper)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startFg()
        if (intent == null || intent.action == "STOP") {
            stopSelf()
            return START_NOT_STICKY
        }
        if (projection != null) return START_NOT_STICKY
        val code = intent.getIntExtra("code", Activity.RESULT_CANCELED)
        val data = dataOf(intent)
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val mp = mgr.getMediaProjection(code, data)
        projection = mp
        mp.registerCallback(cb, handler)
        dpi = resources.displayMetrics.densityDpi
        val (w, h) = realSize()
        applySize(w, h)
        val ov = OverlayPanel(this, bot) { stopSelf() }
        overlay = ov
        ov.show()
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun dataOf(i: Intent): Intent? =
        if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra("data", Intent::class.java)
        else i.getParcelableExtra<Intent>("data")

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "화면 캡처", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 0, Intent(this, CaptureService::class.java).setAction("STOP"),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n: Notification = Notification.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentTitle("킹 레거시 모바일 피쉬 매크로")
            .setContentText("화면 캡처 실행 중 (알림을 누르면 종료)")
            .setContentIntent(stop)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, n)
        }
    }

    @Suppress("DEPRECATION")
    private fun realSize(): Pair<Int, Int> {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.maximumWindowMetrics.bounds
            return Pair(b.width(), b.height())
        }
        val dm = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(dm)
        return Pair(dm.widthPixels, dm.heightPixels)
    }

    private fun applySize(w: Int, h: Int) {
        realW = w
        realH = h
        val s = minOf(1f, 1280f / maxOf(w, h))
        val cw = maxOf(2, (w * s).toInt())
        val ch = maxOf(2, (h * s).toInt())
        reader?.setOnImageAvailableListener(null, null)
        reader?.close()
        val r = ImageReader.newInstance(cw, ch, PixelFormat.RGBA_8888, 2)
        r.setOnImageAvailableListener(listener, handler)
        reader = r
        synchronized(lock) {
            bmp = null
            fw = 0
            fh = 0
        }
        val d = vd
        if (d == null) {
            vd = projection?.createVirtualDisplay(
                "klfish", cw, ch, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, handler
            )
        } else {
            d.resize(cw, ch, dpi)
            d.surface = r.surface
        }
    }

    /** 화면 회전/폴드 전환 시 캡처 크기 갱신 */
    fun checkRotation() {
        val (w, h) = realSize()
        if (w != realW || h != realH) handler.post { applySize(w, h) }
    }

    fun frameSize(): Pair<Int, Int> = Pair(fw, fh)
    fun screenSize(): Pair<Int, Int> = Pair(realW, realH)

    /** 최근 프레임의 [y0, y0+rows) 줄을 out(ARGB)에 복사 */
    fun readRegion(y0: Int, rows: Int, out: IntArray): Boolean {
        synchronized(lock) {
            val b = bmp ?: return false
            if (fw <= 0 || y0 < 0 || y0 + rows > fh) return false
            b.getPixels(out, 0, fw, 0, y0, fw, rows)
            return true
        }
    }

    fun snapshot(): Bitmap? {
        synchronized(lock) {
            val b = bmp ?: return null
            if (fw <= 0 || fh <= 0) return null
            val c = Bitmap.createBitmap(fw, fh, Bitmap.Config.ARGB_8888)
            Canvas(c).drawBitmap(b, 0f, 0f, null)
            return c
        }
    }

    /** 현재 프레임을 Pictures/KLFish 에 PNG로 저장 (튜닝용) */
    fun saveSnapshot(): Boolean {
        val b = snapshot() ?: return false
        val cv = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "klfish_${System.currentTimeMillis()}.png")
            put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/KLFish")
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv) ?: return false
        contentResolver.openOutputStream(uri)?.use { b.compress(Bitmap.CompressFormat.PNG, 100, it) }
        return true
    }

    override fun onDestroy() {
        bot.stop()
        overlay?.remove()
        overlay = null
        try { vd?.release() } catch (e: Exception) { }
        reader?.setOnImageAvailableListener(null, null)
        reader?.close()
        try {
            projection?.unregisterCallback(cb)
            projection?.stop()
        } catch (e: Exception) { }
        projection = null
        thread.quitSafely()
        instance = null
        super.onDestroy()
    }
}
