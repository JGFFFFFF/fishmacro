package com.fishmacro.kl

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private var sp: SharedPreferences? = null

    fun init(c: Context) {
        if (sp == null) sp = c.applicationContext.getSharedPreferences("klfish", Context.MODE_PRIVATE)
    }

    private fun s(): SharedPreferences = sp!!
    fun getInt(k: String, d: Int): Int = s().getInt(k, d)
    fun putInt(k: String, v: Int) { s().edit().putInt(k, v).apply() }
    fun getFloat(k: String, d: Float): Float = s().getFloat(k, d)
    fun putFloat(k: String, v: Float) { s().edit().putFloat(k, v).apply() }

    /** 누를 위치 (화면 좌표, 미지정 = -1) */
    var pressX: Int
        get() = getInt("pressX", -1)
        set(v) { putInt("pressX", v) }
    var pressY: Int
        get() = getInt("pressY", -1)
        set(v) { putInt("pressY", v) }

    /** 영역 지정으로 저장되는 값 (색 0 = 미지정) */
    var targetColor: Int
        get() = getInt("targetColor", 0)
        set(v) { putInt("targetColor", v) }
    var pointerColor: Int
        get() = getInt("pointerColor", 0)
        set(v) { putInt("pointerColor", v) }
    var bandY: Float
        get() = getFloat("bandY", 0.85f)
        set(v) { putFloat("bandY", v) }
    var bandHalf: Float
        get() = getFloat("bandHalf", 0.03f)
        set(v) { putFloat("bandHalf", v) }

    /** 설정 화면 값 */
    var tol: Int
        get() = getInt("tol", 36)
        set(v) { putInt("tol", v) }
    var castMs: Int
        get() = getInt("castMs", 1000)
        set(v) { putInt("castMs", v) }
    var afterMs: Int
        get() = getInt("afterMs", 2500)
        set(v) { putInt("afterMs", v) }
    var biteSec: Int
        get() = getInt("biteSec", 30)
        set(v) { putInt("biteSec", v) }

    /** 누를 때 포인터 이동 방향: 0 자동, 1 오른쪽, -1 왼쪽 */
    var dirMode: Int
        get() = getInt("dirMode", 0)
        set(v) { putInt("dirMode", v) }
}
