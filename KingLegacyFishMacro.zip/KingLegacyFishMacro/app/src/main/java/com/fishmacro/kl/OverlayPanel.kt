package com.fishmacro.kl

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs

/** 게임 위에 떠 있는 컨트롤 패널 (시작/중지, 누를 위치, 영역 지정, 접기, 스냅샷, 종료) */
class OverlayPanel(
    private val ctx: Context,
    private val bot: FishBot,
    private val onExit: () -> Unit
) {
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val ui = Handler(Looper.getMainLooper())
    private var panel: LinearLayout? = null
    private var chip: TextView? = null
    private var removed = false
    private lateinit var tvA11y: TextView
    private lateinit var tvInfo: TextView
    private lateinit var btnStart: TextView

    private val T = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
    private val panelLp = WindowManager.LayoutParams(
        dp(300), WindowManager.LayoutParams.WRAP_CONTENT, T,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(16); y = dp(48) }

    private fun dp(v: Int): Int = (v * ctx.resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(ctx, s, Toast.LENGTH_SHORT).show()

    private fun pill(label: String, bg: Int, sizeSp: Float, click: () -> Unit): TextView {
        val t = TextView(ctx)
        t.text = label
        t.setTextColor(Color.WHITE)
        t.textSize = sizeSp
        t.gravity = Gravity.CENTER
        t.setPadding(dp(6), dp(10), dp(6), dp(10))
        t.background = GradientDrawable().apply { setColor(bg); cornerRadius = dp(14).toFloat() }
        t.setOnClickListener { click() }
        return t
    }

    private fun row(vararg views: View): LinearLayout {
        val r = LinearLayout(ctx)
        r.orientation = LinearLayout.HORIZONTAL
        for (v in views) {
            val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            lp.setMargins(dp(3), dp(3), dp(3), dp(3))
            r.addView(v, lp)
        }
        return r
    }

    fun show() {
        val p = LinearLayout(ctx)
        p.orientation = LinearLayout.VERTICAL
        p.setPadding(dp(14), dp(12), dp(14), dp(12))
        p.background = GradientDrawable().apply { setColor(0xF2141A26.toInt()); cornerRadius = dp(22).toFloat() }

        val title = TextView(ctx)
        title.text = "🎣 킹 레거시 모바일 피쉬 매크로"
        title.setTextColor(Color.WHITE)
        title.textSize = 15f
        title.setTypeface(title.typeface, android.graphics.Typeface.BOLD)
        title.setPadding(0, 0, 0, dp(6))
        title.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f
            var sy = 0f
            var ox = 0
            var oy = 0
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = panelLp.x; oy = panelLp.y }
                    MotionEvent.ACTION_MOVE -> {
                        panelLp.x = ox + (e.rawX - sx).toInt()
                        panelLp.y = oy + (e.rawY - sy).toInt()
                        wm.updateViewLayout(p, panelLp)
                    }
                }
                return true
            }
        })
        p.addView(title)

        tvA11y = TextView(ctx).apply { textSize = 13f }
        tvInfo = TextView(ctx).apply { textSize = 12f; setTextColor(0xFF9CA3AF.toInt()); setPadding(0, dp(2), 0, dp(6)) }
        p.addView(tvA11y)
        p.addView(tvInfo)

        btnStart = pill("시작", 0xFF22C55E.toInt(), 20f) {
            if (bot.running) {
                bot.stop()
                toast("중지")
            } else if (MacroAccessibilityService.instance == null) {
                toast("접근성(2번)을 먼저 켜세요")
            } else if (Prefs.pressX < 0) {
                toast("[누를 위치]를 먼저 지정하세요")
            } else if (Prefs.targetColor == 0 || Prefs.pointerColor == 0) {
                toast("[영역 지정]을 먼저 하세요 (미니게임이 떠 있을 때)")
            } else {
                bot.start()
            }
        }
        btnStart.setTypeface(btnStart.typeface, android.graphics.Typeface.BOLD)
        val sLp = LinearLayout.LayoutParams(-1, -2)
        sLp.setMargins(dp(3), dp(3), dp(3), dp(3))
        p.addView(btnStart, sLp)

        val g = 0xFF2A3345.toInt()
        p.addView(row(
            pill("누를 위치", g, 13f) { pickPoint() },
            pill("영역 지정", g, 13f) { calibrate() },
            pill("접기", g, 13f) { collapse() }
        ))
        p.addView(row(
            pill("스냅샷 저장", g, 13f) {
                toast(if (CaptureService.instance?.saveSnapshot() == true) "Pictures/KLFish 에 저장됨" else "저장 실패 (캡처 프레임 없음)")
            },
            pill("종료", 0xFF7F1D1D.toInt(), 13f) { onExit() }
        ))

        panel = p
        wm.addView(p, panelLp)
        ui.post(tick)
    }

    private val tick = object : Runnable {
        override fun run() {
            if (removed) return
            val ok = MacroAccessibilityService.instance != null
            tvA11y.text = if (ok) "● 접근성 연결됨" else "● 접근성 꺼짐"
            tvA11y.setTextColor(if (ok) 0xFF34D399.toInt() else 0xFFF87171.toInt())
            btnStart.text = if (bot.running) "중지" else "시작"
            (btnStart.background as GradientDrawable).setColor(if (bot.running) 0xFFEF4444.toInt() else 0xFF22C55E.toInt())
            tvInfo.text = if (bot.running) bot.status else bot.probe()
            ui.postDelayed(this, 500)
        }
    }

    private fun fullParams(): WindowManager.LayoutParams {
        val l = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, T,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        if (Build.VERSION.SDK_INT >= 28) {
            l.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        return l
    }

    private fun safeRemove(v: View?) {
        if (v == null) return
        try { wm.removeView(v) } catch (e: Exception) { }
    }

    // ---- 누를 위치 지정 ----
    private fun pickPoint() {
        panel?.visibility = View.GONE
        val root = FrameLayout(ctx)
        root.setBackgroundColor(0x66000000)
        val hint = TextView(ctx)
        hint.text = "게임 화면에서 막대 쪽 '빈 곳'을 한 번 탭하세요"
        hint.setTextColor(Color.WHITE)
        hint.textSize = 18f
        hint.gravity = Gravity.CENTER
        root.addView(hint, FrameLayout.LayoutParams(-1, -1))
        root.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_UP) {
                Prefs.pressX = e.rawX.toInt()
                Prefs.pressY = e.rawY.toInt()
                safeRemove(root)
                panel?.visibility = View.VISIBLE
                marker(Prefs.pressX, Prefs.pressY)
                toast("누를 위치 저장: ${Prefs.pressX}, ${Prefs.pressY}")
            }
            true
        }
        wm.addView(root, fullParams())
    }

    private fun marker(cx: Int, cy: Int) {
        val m = View(ctx)
        m.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xCCFF3B30.toInt()) }
        val l = WindowManager.LayoutParams(
            dp(26), dp(26), T,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        l.gravity = Gravity.TOP or Gravity.START
        l.x = cx - dp(13)
        l.y = cy - dp(13)
        wm.addView(m, l)
        ui.postDelayed({ safeRemove(m) }, 1500)
    }

    // ---- 영역 지정: 정지 화면에서 흰 막대(목표)와 포인터를 탭 ----
    private fun calibrate() {
        val bmp = CaptureService.instance?.snapshot()
        if (bmp == null) {
            toast("캡처 프레임이 없습니다. 게임이 화면에 보이는지 확인하세요")
            return
        }
        panel?.visibility = View.GONE
        val root = FrameLayout(ctx)
        val iv = ImageView(ctx)
        iv.setImageBitmap(bmp)
        iv.scaleType = ImageView.ScaleType.FIT_XY
        val hint = TextView(ctx)
        hint.setBackgroundColor(0xCC000000.toInt())
        hint.setTextColor(Color.WHITE)
        hint.textSize = 17f
        hint.setPadding(dp(14), dp(10), dp(14), dp(10))
        hint.text = "① 흰 막대(목표)를 탭하세요"
        root.addView(iv, FrameLayout.LayoutParams(-1, -1))
        root.addView(hint, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL))

        var step = 0
        var ty = 0
        var tcol = 0
        iv.setOnTouchListener { v, e ->
            if (e.action == MotionEvent.ACTION_UP) {
                val fx = (e.x * bmp.width / v.width).toInt().coerceIn(0, bmp.width - 1)
                val fy = (e.y * bmp.height / v.height).toInt().coerceIn(0, bmp.height - 1)
                if (step == 0) {
                    tcol = bmp.getPixel(fx, fy)
                    ty = fy
                    step = 1
                    hint.text = "② 포인터(움직이는 표시)를 탭하세요"
                } else {
                    Prefs.targetColor = tcol
                    Prefs.pointerColor = outlier(bmp, fx, fy, 10)
                    Prefs.bandY = (ty + fy) / 2f / bmp.height
                    Prefs.bandHalf = maxOf(0.012f, abs(ty - fy) / 2f / bmp.height + 0.012f)
                    safeRemove(root)
                    panel?.visibility = View.VISIBLE
                    toast("영역/색상 저장됨")
                }
            }
            true
        }
        wm.addView(root, fullParams())
    }

    /** 탭 주변에서 평균색과 가장 다른 픽셀(얇은 포인터의 중심색) */
    private fun outlier(b: Bitmap, cx: Int, cy: Int, r: Int): Int {
        val x0 = maxOf(0, cx - r)
        val x1 = minOf(b.width - 1, cx + r)
        val y0 = maxOf(0, cy - r)
        val y1 = minOf(b.height - 1, cy + r)
        var sr = 0L
        var sg = 0L
        var sb = 0L
        var n = 0
        for (y in y0..y1) for (x in x0..x1) {
            val c = b.getPixel(x, y)
            sr += Color.red(c); sg += Color.green(c); sb += Color.blue(c); n++
        }
        val mr = (sr / n).toInt()
        val mg = (sg / n).toInt()
        val mb = (sb / n).toInt()
        var best = b.getPixel(cx, cy)
        var bd = -1
        for (y in y0..y1) for (x in x0..x1) {
            val c = b.getPixel(x, y)
            val d = abs(Color.red(c) - mr) + abs(Color.green(c) - mg) + abs(Color.blue(c) - mb)
            if (d > bd) { bd = d; best = c }
        }
        return best
    }

    // ---- 접기 / 펼치기 ----
    private fun collapse() {
        panel?.visibility = View.GONE
        val c = TextView(ctx)
        c.text = "🎣"
        c.textSize = 22f
        c.gravity = Gravity.CENTER
        c.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xF2141A26.toInt()) }
        val l = WindowManager.LayoutParams(
            dp(48), dp(48), T,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        l.gravity = Gravity.TOP or Gravity.START
        l.x = panelLp.x
        l.y = panelLp.y
        c.setOnClickListener {
            safeRemove(c)
            chip = null
            panel?.visibility = View.VISIBLE
        }
        chip = c
        wm.addView(c, l)
    }

    fun remove() {
        removed = true
        ui.removeCallbacks(tick)
        safeRemove(panel)
        safeRemove(chip)
        panel = null
        chip = null
    }
}
