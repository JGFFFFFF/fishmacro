package com.fishmacro.kl

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val REQ_CAPTURE = 1001
    private lateinit var statusView: TextView
    private lateinit var dirBtn: Button
    private val fields = LinkedHashMap<String, EditText>()

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        buildUi()
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    override fun onPause() {
        saveSettings()
        super.onPause()
    }

    private fun mark(ok: Boolean) = if (ok) "✔" else "✘"

    private fun refreshStatus() {
        statusView.text = "오버레이 ${mark(Settings.canDrawOverlays(this))}    " +
            "접근성 ${mark(MacroAccessibilityService.instance != null)}    " +
            "화면 캡처 ${mark(CaptureService.instance != null)}"
    }

    private fun text(s: String, sp: Float, color: Int): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = sp
        t.setTextColor(color)
        t.setPadding(0, dp(4), 0, dp(4))
        return t
    }

    private fun button(label: String, click: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.textSize = 20f
        b.setOnClickListener { click() }
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.topMargin = dp(8)
        b.layoutParams = lp
        return b
    }

    private fun numRow(label: String, key: String, def: Int): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val tv = TextView(this)
        tv.text = label
        tv.textSize = 15f
        tv.setTextColor(0xFF333333.toInt())
        row.addView(tv, LinearLayout.LayoutParams(0, -2, 1f))
        val et = EditText(this)
        et.inputType = InputType.TYPE_CLASS_NUMBER
        et.setText(Prefs.getInt(key, def).toString())
        fields[key] = et
        row.addView(et, LinearLayout.LayoutParams(dp(110), -2))
        return row
    }

    private fun dirLabel(): String = when (Prefs.dirMode) {
        1 -> "누르면 포인터가 오른쪽으로"
        -1 -> "누르면 포인터가 왼쪽으로"
        else -> "자동 감지"
    }

    private fun buildUi() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(18), dp(14), dp(18), dp(28))
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(0xFFEEEEEE.toInt())
        scroll.addView(root)
        setContentView(scroll)

        root.addView(text("1) 오버레이 권한  2) 접근성 서비스 켜기  3) 화면 캡처 시작", 17f, 0xFF777777.toInt()))
        root.addView(text("게임 화면에서 🎣 메뉴 → [영역 지정](미니게임이 떠 있을 때) → [누를 위치]로 막대 쪽 빈 곳을 한 번 탭 → [시작].", 17f, 0xFF777777.toInt()))
        root.addView(text("※ 게임/Roblox 약관상 매크로는 제재 대상일 수 있습니다. 본인 책임으로 사용하세요.", 15f, 0xFF777777.toInt()))

        statusView = text("", 15f, 0xFF1F2937.toInt())
        root.addView(statusView)

        root.addView(button("1. 오버레이 권한") { requestOverlay() })
        root.addView(button("2. 접근성 설정 열기") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            toast("설치된 앱 → '킹 레거시 모바일 피쉬 매크로' 를 켜세요")
        })
        root.addView(button("3. 화면 캡처 시작") { startCapture() })

        root.addView(text("\n설정", 18f, 0xFF111827.toInt()))
        root.addView(numRow("캐스팅 길게 누르기 (ms)", "castMs", 1000))
        root.addView(numRow("색 허용 오차 (0~255)", "tol", 36))
        root.addView(numRow("낚시 후 대기 (ms)", "afterMs", 2500))
        root.addView(numRow("입질 대기 한도 (초)", "biteSec", 30))
        dirBtn = button("방향: ${dirLabel()}") {
            Prefs.dirMode = when (Prefs.dirMode) { 0 -> 1; 1 -> -1; else -> 0 }
            dirBtn.text = "방향: ${dirLabel()}"
        }
        dirBtn.textSize = 15f
        root.addView(dirBtn)
        val info = button("앱 정보 열기 (제한된 설정 허용)") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
            toast("⋮ 메뉴 → '제한된 설정 허용' 을 누른 뒤 접근성을 켜세요")
        }
        info.textSize = 15f
        root.addView(info)
        root.addView(text("접근성 항목이 회색이라 켜지지 않으면 위 버튼에서 '제한된 설정 허용'을 먼저 해주세요.", 13f, 0xFF777777.toInt()))
    }

    private fun saveSettings() {
        for ((k, e) in fields) {
            e.text.toString().trim().toIntOrNull()?.let { Prefs.putInt(k, it) }
        }
    }

    private fun requestOverlay() {
        if (Settings.canDrawOverlays(this)) {
            toast("오버레이 권한이 이미 허용되어 있습니다 ✔")
        } else {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
    }

    private fun startCapture() {
        if (!Settings.canDrawOverlays(this)) {
            toast("먼저 1번(오버레이 권한)을 허용하세요")
            requestOverlay()
            return
        }
        saveSettings()
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_CAPTURE) return
        if (resultCode == RESULT_OK && data != null) {
            val i = Intent(this, CaptureService::class.java)
                .putExtra("code", resultCode)
                .putExtra("data", data)
            startForegroundService(i)
            toast("화면 캡처 시작! 게임 화면으로 이동하세요")
            moveTaskToBack(true)
        } else {
            toast("화면 공유가 취소되었습니다")
        }
    }
}
