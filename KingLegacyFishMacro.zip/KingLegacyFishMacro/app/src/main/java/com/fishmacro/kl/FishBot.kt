package com.fishmacro.kl

import kotlin.math.abs

/**
 * 낚시 자동화 루프.
 *  1) 캐스팅: 누를 위치를 castMs 동안 길게 눌렀다 뗌 (게이지가 초록 구간일 때 놓는 용도)
 *  2) 입질 대기: 하단 미니게임 막대(목표색 + 포인터색)가 보일 때까지 대기
 *  3) 릴링: 포인터가 흰 막대(목표) 위에 오도록 눌렀다/뗐다 반복
 *  4) 미니게임이 사라지면 afterMs 대기 후 1)로 돌아감
 */
class FishBot {
    @Volatile var running = false
    @Volatile var status = "대기"
    @Volatile var catches = 0

    private var th: Thread? = null
    private var learnedDir = 0
    private var buf = IntArray(0)

    private var holding = false
    private var lastT = 0L
    private var lastP = 0f
    private var lastTx = 0f
    private var vp = 0f
    private var vt = 0f
    private var sh = 0f
    private var nh = 0
    private var sr = 0f
    private var nr = 0

    private class Det(val tx: Float, val tw: Float, val px: Float, val fw: Int)

    fun start() {
        if (running) return
        running = true
        learnedDir = 0
        catches = 0
        th = Thread {
            try {
                loop()
            } catch (e: Exception) {
                status = "오류: ${e.message}"
            }
            running = false
        }.also {
            it.isDaemon = true
            it.start()
        }
    }

    fun stop() {
        running = false
        MacroAccessibilityService.instance?.setHold(false, 0f, 0f)
    }

    /** 실행 중이 아닐 때 오버레이에 보여줄 감지 상태 (영역 지정이 잘 됐는지 확인용) */
    fun probe(): String {
        if (Prefs.targetColor == 0 || Prefs.pointerColor == 0) return "영역 미지정"
        val d = detect() ?: return "미니게임 미감지"
        return "감지됨 · 목표 ${(d.tx * 100 / d.fw).toInt()}% / 포인터 ${(d.px * 100 / d.fw).toInt()}%"
    }

    private fun loop() {
        var state = 0 // 0 캐스팅, 1 입질 대기, 2 릴링, 3 완료
        var waitStart = 0L
        var present = 0
        var lostSince = 0L
        var lastRot = 0L
        while (running) {
            val svc = MacroAccessibilityService.instance
            val cap = CaptureService.instance
            if (svc == null) { status = "접근성 꺼짐"; sleep(500); continue }
            if (cap == null) { status = "화면 캡처 필요"; sleep(500); continue }
            val now = System.currentTimeMillis()
            if (now - lastRot > 1000) { cap.checkRotation(); lastRot = now }
            val px = Prefs.pressX.toFloat()
            val py = Prefs.pressY.toFloat()
            when (state) {
                0 -> {
                    status = "캐스팅 (${catches}회 완료)"
                    svc.setHold(true, px, py)
                    sleep(Prefs.castMs.toLong())
                    svc.setHold(false, px, py)
                    sleep(400)
                    state = 1
                    waitStart = System.currentTimeMillis()
                    present = 0
                }
                1 -> {
                    status = "입질 대기 (${catches}회 완료)"
                    if (detect() != null) present++ else present = 0
                    if (present >= 3) {
                        state = 2
                        lostSince = 0L
                        resetCtl()
                    } else if (now - waitStart > Prefs.biteSec * 1000L) {
                        state = 0
                    }
                    sleep(40)
                }
                2 -> {
                    val d = detect()
                    if (d != null) {
                        lostSince = 0L
                        control(d, svc, px, py)
                    } else {
                        if (lostSince == 0L) lostSince = now
                        if (now - lostSince > 1200) state = 3
                    }
                    sleep(20)
                }
                else -> {
                    svc.setHold(false, px, py)
                    holding = false
                    catches++
                    status = "${catches}회 완료 · 잠시 대기"
                    sleep(Prefs.afterMs.toLong())
                    state = 0
                }
            }
        }
        MacroAccessibilityService.instance?.setHold(false, 0f, 0f)
        status = "중지됨"
    }

    private fun resetCtl() {
        holding = false
        lastT = 0L
        vp = 0f
        vt = 0f
        sh = 0f; nh = 0; sr = 0f; nr = 0
    }

    private fun control(d: Det, svc: MacroAccessibilityService, x: Float, y: Float) {
        val now = System.nanoTime()
        if (lastT != 0L) {
            val dt = (now - lastT) / 1e9f
            if (dt in 0.005f..0.5f) {
                val a = (d.px - lastP) / dt
                val b = (d.tx - lastTx) / dt
                vp = vp * 0.5f + a * 0.5f
                vt = vt * 0.5f + b * 0.5f
                // 누를 때 포인터가 어느 쪽으로 가는지 자동 학습
                if (learnedDir == 0 && abs(a) < d.fw * 4f) {
                    if (holding) { sh += a; nh++ } else { sr += a; nr++ }
                    if (nh >= 6 && nr >= 6) {
                        val diff = sh / nh - sr / nr
                        if (abs(diff) > d.fw * 0.03f) {
                            learnedDir = if (diff > 0) 1 else -1
                        } else {
                            sh = 0f; nh = 0; sr = 0f; nr = 0
                        }
                    }
                }
            }
        }
        lastT = now
        lastP = d.px
        lastTx = d.tx

        val dir = if (Prefs.dirMode != 0) Prefs.dirMode else learnedDir
        val want: Boolean
        if (dir == 0) {
            status = "릴링: 방향 학습 중"
            want = (System.currentTimeMillis() / 250) % 2L == 0L
        } else {
            val lead = 0.08f
            val err = (d.tx + vt * lead) - (d.px + vp * lead)
            val wantRight = err > 0f
            want = if (dir > 0) wantRight else !wantRight
            status = "릴링 중 (${catches}회 완료)"
        }
        if (want != holding) {
            holding = want
            svc.setHold(want, x, y)
        }
    }

    @Synchronized
    private fun detect(): Det? {
        val cap = CaptureService.instance ?: return null
        val tc = Prefs.targetColor
        val pc = Prefs.pointerColor
        if (tc == 0 || pc == 0) return null
        val (fw, fh) = cap.frameSize()
        if (fw <= 0 || fh <= 0) return null
        val cy = (Prefs.bandY * fh).toInt()
        val half = maxOf(2, (Prefs.bandHalf * fh).toInt())
        val y0 = maxOf(0, cy - half)
        val y1 = minOf(fh, cy + half + 1)
        val rows = y1 - y0
        if (rows <= 0) return null
        if (buf.size < fw * rows) buf = IntArray(fw * rows)
        if (!cap.readRegion(y0, rows, buf)) return null

        val tol = Prefs.tol
        val tcol = BooleanArray(fw)
        val pcol = BooleanArray(fw)
        for (r in 0 until rows) {
            val o = r * fw
            for (x in 0 until fw) {
                val c = buf[o + x]
                if (near(c, tc, tol)) tcol[x] = true
                if (near(c, pc, tol)) pcol[x] = true
            }
        }
        val t = bestRun(tcol, maxOf(2, fw / 40)) ?: return null
        if (t[1] - t[0] + 1 < maxOf(3, fw / 80)) return null
        val p = bestRun(pcol, 1) ?: return null
        if (p[1] - p[0] + 1 < 2) return null
        return Det((t[0] + t[1]) / 2f, (t[1] - t[0] + 1).toFloat(), (p[0] + p[1]) / 2f, fw)
    }

    private fun near(c: Int, ref: Int, tol: Int): Boolean {
        return abs(((c shr 16) and 255) - ((ref shr 16) and 255)) <= tol &&
            abs(((c shr 8) and 255) - ((ref shr 8) and 255)) <= tol &&
            abs((c and 255) - (ref and 255)) <= tol
    }

    /** 가장 긴 연속 구간(틈 gap 허용)의 [시작, 끝] */
    private fun bestRun(col: BooleanArray, gap: Int): IntArray? {
        var bestS = -1
        var bestE = -1
        var bestLen = -1
        var s = -1
        var e = -1
        var g = 0
        for (x in col.indices) {
            if (col[x]) {
                if (s < 0) s = x
                e = x
                g = 0
            } else if (s >= 0) {
                g++
                if (g > gap) {
                    if (e - s > bestLen) { bestLen = e - s; bestS = s; bestE = e }
                    s = -1
                    g = 0
                }
            }
        }
        if (s >= 0 && e - s > bestLen) { bestS = s; bestE = e }
        return if (bestS < 0) null else intArrayOf(bestS, bestE)
    }

    private fun sleep(ms: Long) {
        try {
            Thread.sleep(ms)
        } catch (e: InterruptedException) {
        }
    }
}
